const express = require('express');
const router = express.Router();
const whatsappController = require('../controllers/whatsappController');
const whatsappService = require('../services/whatsappService');
const db = require('../config/db');

// cronService opsiyonel - dosya yoksa bile diğer route'lar çalışır
let cronService = null;
try {
    cronService = require('../services/cronService');
    console.log('✅ cronService yüklendi');
} catch (e) {
    console.log('⚠️ cronService yüklenemedi:', e.message);
}

// Middleware: Oturum kontrolü
const authCheck = (req, res, next) => {
    if (!req.session.userID) {
        return res.redirect('/api/auth/login');
    }
    next();
};

// Middleware: Yönetici kontrolü
const adminCheck = (req, res, next) => {
    if (req.session.rol !== 'yonetici') {
        return res.status(403).send('Bu sayfaya erişim yetkiniz yok');
    }
    next();
};

// =====================================================
// ⚠️ WEBHOOK - AUTH GEREKTİRMEZ (EN ÜSTTE!)
// =====================================================
router.post('/webhook', whatsappController.webhookReceive);

router.get('/webhook-test', (req, res) => {
    res.json({ success: true, message: 'Webhook route çalışıyor!' });
});

// =====================================================
// SAYFA ROTALARI
// =====================================================

// QR Bağlantı Sayfası
router.get('/qr', authCheck, adminCheck, whatsappController.qrSayfasi);

// Otomatik Mesajlar Sayfası
router.get('/otomatik-mesajlar', authCheck, adminCheck, whatsappController.otomatikMesajlarSayfasi);

// =====================================================
// 🆕 WHATSAPP CHAT SAYFALARI
// =====================================================

// Chat Ana Sayfası
router.get('/chat', authCheck, whatsappController.chatSayfasi);

// ⚠️ ÖNEMLİ: Parametresiz route'lar :id'den ÖNCE tanımlanmalı!
router.get('/chat/check-updates', authCheck, whatsappController.chatCheckUpdates);
router.get('/chat/arsiv-listesi', authCheck, whatsappController.chatArsivListesi);
router.post('/chat/kisi-kaydet', authCheck, whatsappController.chatKisiKaydet);

// Parametreli route'lar
router.get('/chat/:id', authCheck, whatsappController.chatDetay);
router.get('/chat/:id/mesajlar', authCheck, whatsappController.chatMesajlariGetir);
router.post('/chat/:id/gonder', authCheck, whatsappController.chatMesajGonder);
router.post('/chat/:id/arsivle', authCheck, whatsappController.chatArsivle);
router.post('/chat/:id/arsivden-cikar', authCheck, whatsappController.chatArsivdenCikar);
router.post('/chat/:id/grup', authCheck, whatsappController.chatGrupGuncelle);
router.post('/chat/:id/tuttur', authCheck, whatsappController.chatTuttur);
router.post('/chat/:id/resim-gonder', authCheck, whatsappController.chatResimGonder);
router.post('/chat/:id/isim-guncelle', authCheck, whatsappController.chatIsimGuncelle);
router.delete('/chat/:id/sil', authCheck, whatsappController.chatSil);

// =====================================================
// API ROTALARI
// =====================================================

// Ayarları Kaydet
router.post('/settings/save', authCheck, adminCheck, whatsappController.mesajAyarlariKaydet);

// Cihaz Ekleme
router.post('/device/add', authCheck, adminCheck, whatsappController.addDevice);

// Cihaz Bağlama (QR/Code)
router.post('/device/connect', authCheck, adminCheck, whatsappController.connectDevice);

// Cihaz Durumu Sorgulama
router.get('/device/status', authCheck, adminCheck, whatsappController.deviceStatus);

// Durum Güncelleme (Yerel DB)
router.post('/device/update-status', authCheck, adminCheck, whatsappController.updateStatus);

// Çıkış Yapma (Logout)
router.post('/device/logout', authCheck, adminCheck, whatsappController.logoutDevice);

// Cihaz Silme
router.delete('/device/delete', authCheck, adminCheck, whatsappController.deleteDevice);

// Bağlantı Kontrolü
router.get('/check-connection', authCheck, whatsappController.checkConnection);

// Toplu İşlemler Sayfası
router.get('/toplu-islemler', authCheck, whatsappController.topluIslemlerSayfasi);

// Manuel Mesaj Gönder API
router.post('/toplu-islemler/manuel-gonder', authCheck, whatsappController.manuelMesajGonder);

// Toplu Mesaj Gönder API (Branş/Grup)
router.post('/toplu-islemler/toplu-gonder', authCheck, whatsappController.topluMesajGonder);


// =====================================================
// ŞABLONLAR
// =====================================================
router.get('/sablonlar', authCheck, async (req, res) => {
    const subeId = req.query.sube_id || req.session.subeId;
    
    try {
        const [sablonlar] = await db.execute(`
            SELECT * FROM whatsapp_sablonlar 
            WHERE (sube_id = ? OR sube_id IS NULL) AND aktif = 1
            ORDER BY sira ASC
        `, [subeId]);
        
        res.json({ success: true, sablonlar: sablonlar });
    } catch (error) {
        console.error('Şablon getirme hatası:', error);
        res.json({ success: false, message: error.message });
    }
});

// =====================================================
// BAŞVURU FORMU MESAJ GÖNDERİMİ
// =====================================================
router.post('/send-basvuru', authCheck, async (req, res) => {
    const { sube_id, telefon, mesaj } = req.body;
    
    if (!sube_id || !telefon || !mesaj) {
        return res.status(400).json({ success: false, message: 'Eksik parametreler' });
    }
    
    try {
        // Telefon formatla
        let phone = telefon.toString().replace(/\D/g, '');
        
        if (phone.length === 11 && phone[0] === '0') {
            phone = '90' + phone.substring(1);
        } else if (phone.length === 10) {
            phone = '90' + phone;
        }
        
        // whatsappService ile gönder
        await whatsappService.sendManualMessage(sube_id, phone, mesaj);
        
        res.json({ success: true, message: 'Mesaj gönderildi' });
        
    } catch (error) {
        console.error('WhatsApp mesaj hatası:', error.message);
        res.status(500).json({ success: false, message: error.message || 'Mesaj gönderilemedi' });
    }
});

// =====================================================
// MANUEL MESAJ GÖNDER (Öğrenci Listesi için)
// =====================================================
router.post('/send-manual', authCheck, async (req, res) => {
    const { sube_id, telefon, mesaj } = req.body;
    
    console.log('📱 Manuel mesaj isteği:', { sube_id, telefon: telefon?.substring(0, 5) + '***', mesajUzunluk: mesaj?.length });
    
    if (!telefon || !mesaj) {
        return res.status(400).json({ success: false, message: 'Telefon ve mesaj gerekli' });
    }
    
    try {
        // Telefon formatla
        let phone = telefon.toString().replace(/\D/g, '');
        
        // Türkiye formatı
        if (phone.length === 10 && ['5', '8', '2', '3', '4'].includes(phone[0])) {
            phone = '90' + phone;
        } else if (phone.length === 11 && phone[0] === '0') {
            phone = '90' + phone.substring(1);
        }
        
        // Şube ID belirle
        const subeIdToUse = sube_id || req.session.subeId;
        
        if (!subeIdToUse) {
            return res.status(400).json({ success: false, message: 'Şube ID bulunamadı' });
        }
        
        console.log('📤 Mesaj gönderiliyor:', { subeId: subeIdToUse, phone });
        
        // whatsappService ile gönder
        await whatsappService.sendManualMessage(subeIdToUse, phone, mesaj);
        
        console.log('✅ Mesaj gönderildi');
        res.json({ success: true, message: 'Mesaj gönderildi' });
        
    } catch (error) {
        console.error('❌ WhatsApp mesaj hatası:', error);
        res.status(500).json({ success: false, message: error.message || 'Mesaj gönderilemedi' });
    }
});

// =====================================================
// 🕐 CRON TEST ENDPOİNTLERİ
// =====================================================
const CRON_SECRET_KEY = 'cron_test_2024_secret';

const cronAuthCheck = (req, res, next) => {
    if (req.query.key === CRON_SECRET_KEY) {
        return next();
    }
    if (req.session && req.session.userID && req.session.rol === 'yonetici') {
        return next();
    }
    return res.status(401).json({ 
        success: false, 
        message: 'Yetkisiz erişim. ?key=SECRET_KEY parametresi ekleyin.' 
    });
};

// 🔍 DEBUG: Neden mesaj gönderilmediğini göster
router.get('/cron/debug/aidat', cronAuthCheck, async (req, res) => {
    try {
        const bugun = new Date();
        const bugunGun = bugun.getDate();
        const buAy = bugun.getMonth() + 1;
        const buYil = bugun.getFullYear();

        const debugInfo = {
            tarih: bugun.toLocaleString('tr-TR'),
            bugunGun,
            buAy,
            buYil,
            kontroller: []
        };

        // 1. Mesaj ayarları kontrolü
        const [ayarlar] = await db.execute(`
            SELECT sube_id, aidat_hatirlatma_aktif, aidat_hatirlatma_mesaj 
            FROM whatsapp_mesaj_ayarlari
        `);
        debugInfo.mesajAyarlari = ayarlar;

        // 2. WhatsApp bağlantısı kontrolü
        const [wpApi] = await db.execute(`SELECT sube_id, durum FROM wp_api`);
        debugInfo.wpApiBaglantilari = wpApi;

        // 3. Bugün hatırlatma günü olan öğrenciler
        const [ogrenciler] = await db.execute(`
            SELECT o.id, o.ad_soyad, o.sube_id, o.aidat_hatirlatma_gunu, o.aidat_ucreti, o.ozel_veri, o.durum
            FROM ogrenciler o
            WHERE o.aidat_hatirlatma_gunu = ?
            AND o.durum = 'aktif'
            LIMIT 20
        `, [bugunGun]);
        
        debugInfo.bugunHatirlatmaGunuOlanlar = ogrenciler.map(o => ({
            id: o.id,
            ad_soyad: o.ad_soyad,
            sube_id: o.sube_id,
            aidat_hatirlatma_gunu: o.aidat_hatirlatma_gunu,
            aidat_ucreti: o.aidat_ucreti,
            durum: o.durum,
            telefonVar: o.ozel_veri ? 'evet' : 'hayır'
        }));

        // 4. Her öğrenci için detaylı kontrol
        for (const ogr of ogrenciler.slice(0, 5)) {
            const ogrDebug = {
                ogrenci: ogr.ad_soyad,
                ogrenci_id: ogr.id,
                sube_id: ogr.sube_id,
                kontroller: {}
            };

            // Aidat ödenmiş mi?
            const [aidatKontrol] = await db.execute(`
                SELECT id, durum FROM aidatlar 
                WHERE ogrenci_id = ? AND yil = ? AND ay = ?
            `, [ogr.id, buYil, buAy]);
            ogrDebug.kontroller.aidatDurumu = aidatKontrol.length > 0 
                ? `Kayıt var: ${aidatKontrol[0].durum}` 
                : 'Aidat kaydı yok';

            // Şube ayarı aktif mi?
            const subeAyar = ayarlar.find(a => a.sube_id === ogr.sube_id);
            ogrDebug.kontroller.subeAyari = subeAyar 
                ? `Aktif: ${subeAyar.aidat_hatirlatma_aktif}, Mesaj: ${subeAyar.aidat_hatirlatma_mesaj ? 'var' : 'yok'}`
                : 'Şube ayarı YOK!';

            // WhatsApp bağlantısı var mı?
            const wpBaglanti = wpApi.find(w => w.sube_id === ogr.sube_id);
            ogrDebug.kontroller.wpBaglanti = wpBaglanti 
                ? `Durum: ${wpBaglanti.durum}` 
                : 'WhatsApp bağlantısı YOK!';

            // Telefon var mı?
            let telefonlar = [];
            if (ogr.ozel_veri) {
                try {
                    const data = JSON.parse(ogr.ozel_veri);
                    const alanlar = ['baba_telefon', 'anne_telefon', 'veli_telefon', 'telefon'];
                    for (const alan of alanlar) {
                        if (data[alan]) telefonlar.push(`${alan}: ${data[alan]}`);
                    }
                } catch(e) {}
            }
            ogrDebug.kontroller.telefonlar = telefonlar.length > 0 ? telefonlar : 'Telefon YOK!';

            // Bugün mesaj gönderilmiş mi?
            const [logKontrol] = await db.execute(`
                SELECT id, durum, gonderim_tarihi FROM whatsapp_mesaj_log 
                WHERE ogrenci_id = ? AND mesaj_tipi = 'aidat_hatirlatma' 
                AND DATE(gonderim_tarihi) = CURDATE()
            `, [ogr.id]);
            ogrDebug.kontroller.bugunMesajGonderilmisMi = logKontrol.length > 0 
                ? `EVET - ${logKontrol[0].durum}` 
                : 'Hayır';

            debugInfo.kontroller.push(ogrDebug);
        }

        // 5. Tüm öğrencilerin aidat_hatirlatma_gunu dağılımı
        const [gunDagilimi] = await db.execute(`
            SELECT aidat_hatirlatma_gunu, COUNT(*) as adet 
            FROM ogrenciler 
            WHERE durum = 'aktif'
            GROUP BY aidat_hatirlatma_gunu
            ORDER BY aidat_hatirlatma_gunu
        `);
        debugInfo.gunDagilimi = gunDagilimi;

        res.json({ success: true, debug: debugInfo });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message, stack: error.stack });
    }
});

// Veritabanı kontrolü
router.get('/cron/check-db', cronAuthCheck, async (req, res) => {
    const results = {
        cronService_loaded: cronService !== null,
        wp_api: false,
        whatsapp_mesaj_ayarlari: false,
        whatsapp_mesaj_log: false,
        ogrenciler_aidat_gunu: false,
        mesaj_ayarlari_cron_kolonlari: false,
        mesaj_log_referans_kolonlari: false
    };
    const errors = [];

    if (!cronService) {
        errors.push('cronService yüklenemedi - /services/cronService.js dosyasını ekleyin');
    }

    try {
        try {
            const [wpApi] = await db.execute('SELECT COUNT(*) as cnt FROM wp_api WHERE durum = 1');
            results.wp_api = true;
            results.wp_api_count = wpApi[0].cnt;
        } catch (e) {
            errors.push('wp_api: ' + e.message);
        }

        try {
            const [ayarlar] = await db.execute('SELECT COUNT(*) as cnt FROM whatsapp_mesaj_ayarlari');
            results.whatsapp_mesaj_ayarlari = true;
            results.mesaj_ayarlari_count = ayarlar[0].cnt;
        } catch (e) {
            errors.push('whatsapp_mesaj_ayarlari: ' + e.message);
        }

        try {
            const [log] = await db.execute('SELECT COUNT(*) as cnt FROM whatsapp_mesaj_log');
            results.whatsapp_mesaj_log = true;
            results.mesaj_log_count = log[0].cnt;
        } catch (e) {
            errors.push('whatsapp_mesaj_log: ' + e.message);
        }

        try {
            await db.execute('SELECT aidat_hatirlatma_gunu FROM ogrenciler LIMIT 1');
            results.ogrenciler_aidat_gunu = true;
        } catch (e) {
            errors.push('ogrenciler.aidat_hatirlatma_gunu: ' + e.message);
        }

        try {
            await db.execute('SELECT aidat_hatirlatma_aktif FROM whatsapp_mesaj_ayarlari LIMIT 1');
            results.mesaj_ayarlari_cron_kolonlari = true;
        } catch (e) {
            errors.push('mesaj_ayarlari cron kolonları: ' + e.message);
        }

        try {
            await db.execute('SELECT referans_ay FROM whatsapp_mesaj_log LIMIT 1');
            results.mesaj_log_referans_kolonlari = true;
        } catch (e) {
            errors.push('mesaj_log referans kolonları: ' + e.message);
        }

        const allOk = Object.values(results).every(v => v === true || typeof v === 'number');
        res.json({ success: allOk, results, errors });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message, results, errors });
    }
});

// Tüm cron'ları çalıştır
router.get('/cron/test', cronAuthCheck, async (req, res) => {
    if (!cronService) {
        return res.status(503).json({ success: false, message: 'cronService yüklenmedi' });
    }
    try {
        await cronService.runAllCrons();
        res.json({ success: true, message: 'Tüm cron işlemleri tamamlandı' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Aidat hatırlatma
router.get('/cron/test/aidat-hatirlatma', cronAuthCheck, async (req, res) => {
    if (!cronService) {
        return res.status(503).json({ success: false, message: 'cronService yüklenmedi' });
    }
    try {
        await cronService.aidatHatirlatmaCron();
        res.json({ success: true, message: 'Aidat hatırlatma cron tamamlandı' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Gecikmiş aidat
router.get('/cron/test/aidat-gecmis', cronAuthCheck, async (req, res) => {
    if (!cronService) {
        return res.status(503).json({ success: false, message: 'cronService yüklenmedi' });
    }
    try {
        await cronService.aidatGecikmisCron();
        res.json({ success: true, message: 'Gecikmiş aidat cron tamamlandı' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Paket bitiş
router.get('/cron/test/paket-bitim', cronAuthCheck, async (req, res) => {
    if (!cronService) {
        return res.status(503).json({ success: false, message: 'cronService yüklenmedi' });
    }
    try {
        await cronService.paketBitimCron();
        res.json({ success: true, message: 'Paket bitiş cron tamamlandı' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Özel ders bitiş
router.get('/cron/test/ozel-ders-bitim', cronAuthCheck, async (req, res) => {
    if (!cronService) {
        return res.status(503).json({ success: false, message: 'cronService yüklenmedi' });
    }
    try {
        await cronService.ozelDersBitimCron();
        res.json({ success: true, message: 'Özel ders bitiş cron tamamlandı' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Taksit hatırlatma
router.get('/cron/test/taksit-hatirlatma', cronAuthCheck, async (req, res) => {
    if (!cronService) {
        return res.status(503).json({ success: false, message: 'cronService yüklenmedi' });
    }
    try {
        await cronService.taksitHatirlatmaCron();
        res.json({ success: true, message: 'Taksit hatırlatma cron tamamlandı' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Doğum günü
router.get('/cron/test/dogum-gunu', cronAuthCheck, async (req, res) => {
    if (!cronService) {
        return res.status(503).json({ success: false, message: 'cronService yüklenmedi' });
    }
    try {
        await cronService.dogumGunuCron();
        res.json({ success: true, message: 'Doğum günü cron tamamlandı' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Cron durumu
router.get('/cron/status', cronAuthCheck, async (req, res) => {
    try {
        const [logs] = await db.execute(`
            SELECT mesaj_tipi, durum, COUNT(*) as adet, MAX(gonderim_tarihi) as son_gonderim
            FROM whatsapp_mesaj_log
            WHERE gonderim_tarihi >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            GROUP BY mesaj_tipi, durum
            ORDER BY son_gonderim DESC
        `);
        res.json({ success: true, logs });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = router;