const express = require('express');
const router = express.Router();
const whatsappController = require('../controllers/whatsappController');
const whatsappService = require('../services/whatsappService');
const cronService = require('../services/cronService');
const db = require('../config/db');

// Middleware: Oturum kontrolü
const authCheck = (req, res, next) => {
    if (!req.session.userID) {
        return res.redirect('/api/auth/login');
    }
    next();
};

// Middleware: Yönetici kontrolü
const adminCheck = (req, res, next) => {
    if (req.session.rol !== 'yonetici') {
        return res.status(403).send('Bu sayfaya erişim yetkiniz yok');
    }
    next();
};

// =====================================================
// ⚠️ WEBHOOK - AUTH GEREKTİRMEZ (EN ÜSTTE!)
// =====================================================
router.post('/webhook', whatsappController.webhookReceive);

router.get('/webhook-test', (req, res) => {
    res.json({ success: true, message: 'Webhook route çalışıyor!' });
});

// =====================================================
// SAYFA ROTALARI
// =====================================================

// QR Bağlantı Sayfası
router.get('/qr', authCheck, adminCheck, whatsappController.qrSayfasi);

// Otomatik Mesajlar Sayfası
router.get('/otomatik-mesajlar', authCheck, adminCheck, whatsappController.otomatikMesajlarSayfasi);

// =====================================================
// 🆕 WHATSAPP CHAT SAYFALARI
// =====================================================

// Chat Ana Sayfası
router.get('/chat', authCheck, whatsappController.chatSayfasi);

// ⚠️ ÖNEMLİ: Parametresiz route'lar :id'den ÖNCE tanımlanmalı!
router.get('/chat/check-updates', authCheck, whatsappController.chatCheckUpdates);
router.get('/chat/arsiv-listesi', authCheck, whatsappController.chatArsivListesi);
router.post('/chat/kisi-kaydet', authCheck, whatsappController.chatKisiKaydet);

// Parametreli route'lar
router.get('/chat/:id', authCheck, whatsappController.chatDetay);
router.get('/chat/:id/mesajlar', authCheck, whatsappController.chatMesajlariGetir);
router.post('/chat/:id/gonder', authCheck, whatsappController.chatMesajGonder);
router.post('/chat/:id/arsivle', authCheck, whatsappController.chatArsivle);
router.post('/chat/:id/arsivden-cikar', authCheck, whatsappController.chatArsivdenCikar);
router.post('/chat/:id/grup', authCheck, whatsappController.chatGrupGuncelle);
router.post('/chat/:id/tuttur', authCheck, whatsappController.chatTuttur);
router.post('/chat/:id/resim-gonder', authCheck, whatsappController.chatResimGonder);
router.post('/chat/:id/isim-guncelle', authCheck, whatsappController.chatIsimGuncelle);
router.delete('/chat/:id/sil', authCheck, whatsappController.chatSil);

// =====================================================
// API ROTALARI
// =====================================================

// Ayarları Kaydet
router.post('/settings/save', authCheck, adminCheck, whatsappController.mesajAyarlariKaydet);

// Cihaz Ekleme
router.post('/device/add', authCheck, adminCheck, whatsappController.addDevice);

// Cihaz Bağlama (QR/Code)
router.post('/device/connect', authCheck, adminCheck, whatsappController.connectDevice);

// Cihaz Durumu Sorgulama
router.get('/device/status', authCheck, adminCheck, whatsappController.deviceStatus);

// Durum Güncelleme (Yerel DB)
router.post('/device/update-status', authCheck, adminCheck, whatsappController.updateStatus);

// Çıkış Yapma (Logout)
router.post('/device/logout', authCheck, adminCheck, whatsappController.logoutDevice);

// Cihaz Silme
router.delete('/device/delete', authCheck, adminCheck, whatsappController.deleteDevice);

// Bağlantı Kontrolü
router.get('/check-connection', authCheck, whatsappController.checkConnection);

// Toplu İşlemler Sayfası
router.get('/toplu-islemler', authCheck, whatsappController.topluIslemlerSayfasi);

// Manuel Mesaj Gönder API
router.post('/toplu-islemler/manuel-gonder', authCheck, whatsappController.manuelMesajGonder);

// Toplu Mesaj Gönder API (Branş/Grup)
router.post('/toplu-islemler/toplu-gonder', authCheck, whatsappController.topluMesajGonder);


// =====================================================
// ŞABLONLAR
// =====================================================
router.get('/sablonlar', authCheck, async (req, res) => {
    const subeId = req.query.sube_id || req.session.subeId;
    
    try {
        const [sablonlar] = await db.execute(`
            SELECT * FROM whatsapp_sablonlar 
            WHERE (sube_id = ? OR sube_id IS NULL) AND aktif = 1
            ORDER BY sira ASC
        `, [subeId]);
        
        res.json({ success: true, sablonlar: sablonlar });
    } catch (error) {
        console.error('Şablon getirme hatası:', error);
        res.json({ success: false, message: error.message });
    }
});

// =====================================================
// BAŞVURU FORMU MESAJ GÖNDERİMİ
// =====================================================
router.post('/send-basvuru', authCheck, async (req, res) => {
    const { sube_id, telefon, mesaj } = req.body;
    
    if (!sube_id || !telefon || !mesaj) {
        return res.status(400).json({ success: false, message: 'Eksik parametreler' });
    }
    
    try {
        // Telefon formatla
        let phone = telefon.toString().replace(/\D/g, '');
        
        if (phone.length === 11 && phone[0] === '0') {
            phone = '90' + phone.substring(1);
        } else if (phone.length === 10) {
            phone = '90' + phone;
        }
        
        // whatsappService ile gönder
        await whatsappService.sendManualMessage(sube_id, phone, mesaj);
        
        res.json({ success: true, message: 'Mesaj gönderildi' });
        
    } catch (error) {
        console.error('WhatsApp mesaj hatası:', error.message);
        res.status(500).json({ success: false, message: error.message || 'Mesaj gönderilemedi' });
    }
});

// =====================================================
// MANUEL MESAJ GÖNDER (Öğrenci Listesi için)
// =====================================================
router.post('/send-manual', authCheck, async (req, res) => {
    const { sube_id, telefon, mesaj } = req.body;
    
    console.log('📱 Manuel mesaj isteği:', { sube_id, telefon: telefon?.substring(0, 5) + '***', mesajUzunluk: mesaj?.length });
    
    if (!telefon || !mesaj) {
        return res.status(400).json({ success: false, message: 'Telefon ve mesaj gerekli' });
    }
    
    try {
        // Telefon formatla
        let phone = telefon.toString().replace(/\D/g, '');
        
        // Türkiye formatı
        if (phone.length === 10 && ['5', '8', '2', '3', '4'].includes(phone[0])) {
            phone = '90' + phone;
        } else if (phone.length === 11 && phone[0] === '0') {
            phone = '90' + phone.substring(1);
        }
        
        // Şube ID belirle
        const subeIdToUse = sube_id || req.session.subeId;
        
        if (!subeIdToUse) {
            return res.status(400).json({ success: false, message: 'Şube ID bulunamadı' });
        }
        
        console.log('📤 Mesaj gönderiliyor:', { subeId: subeIdToUse, phone });
        
        // whatsappService ile gönder
        await whatsappService.sendManualMessage(subeIdToUse, phone, mesaj);
        
        console.log('✅ Mesaj gönderildi');
        res.json({ success: true, message: 'Mesaj gönderildi' });
        
    } catch (error) {
        console.error('❌ WhatsApp mesaj hatası:', error);
        res.status(500).json({ success: false, message: error.message || 'Mesaj gönderilemedi' });
    }
});

// =====================================================
// 🕐 CRON TEST ENDPOİNTLERİ (Sadece Yönetici)
// =====================================================

// Tüm cron'ları manuel çalıştır
router.get('/cron/test', authCheck, adminCheck, async (req, res) => {
    try {
        console.log('🧪 Manuel cron testi başlatıldı...');
        await cronService.runAllCrons();
        res.json({ success: true, message: 'Tüm cron işlemleri tamamlandı' });
    } catch (error) {
        console.error('Cron test hatası:', error);
        res.status(500).json({ 
            success: false, 
            message: error.message,
            stack: error.stack,
            tip: 'SQL güncellemelerini yaptığınızdan emin olun: whatsapp_cron_sql.sql'
        });
    }
});

// Veritabanı kontrolü - cron için gerekli yapı var mı?
router.get('/cron/check-db', authCheck, adminCheck, async (req, res) => {
    const results = {
        wp_api: false,
        whatsapp_mesaj_ayarlari: false,
        whatsapp_mesaj_log: false,
        ogrenciler_aidat_gunu: false,
        mesaj_ayarlari_cron_kolonlari: false,
        mesaj_log_referans_kolonlari: false
    };
    const errors = [];

    try {
        // 1. wp_api tablosu var mı?
        try {
            const [wpApi] = await db.execute('SELECT COUNT(*) as cnt FROM wp_api WHERE durum = 1');
            results.wp_api = true;
            results.wp_api_count = wpApi[0].cnt;
        } catch (e) {
            errors.push('wp_api tablosu bulunamadı: ' + e.message);
        }

        // 2. whatsapp_mesaj_ayarlari tablosu var mı?
        try {
            const [ayarlar] = await db.execute('SELECT COUNT(*) as cnt FROM whatsapp_mesaj_ayarlari');
            results.whatsapp_mesaj_ayarlari = true;
            results.mesaj_ayarlari_count = ayarlar[0].cnt;
        } catch (e) {
            errors.push('whatsapp_mesaj_ayarlari tablosu bulunamadı: ' + e.message);
        }

        // 3. whatsapp_mesaj_log tablosu var mı?
        try {
            const [log] = await db.execute('SELECT COUNT(*) as cnt FROM whatsapp_mesaj_log');
            results.whatsapp_mesaj_log = true;
            results.mesaj_log_count = log[0].cnt;
        } catch (e) {
            errors.push('whatsapp_mesaj_log tablosu bulunamadı: ' + e.message);
        }

        // 4. ogrenciler tablosunda aidat_hatirlatma_gunu var mı?
        try {
            await db.execute('SELECT aidat_hatirlatma_gunu FROM ogrenciler LIMIT 1');
            results.ogrenciler_aidat_gunu = true;
        } catch (e) {
            errors.push('ogrenciler.aidat_hatirlatma_gunu kolonu bulunamadı: ' + e.message);
        }

        // 5. whatsapp_mesaj_ayarlari'nda cron kolonları var mı?
        try {
            await db.execute('SELECT aidat_hatirlatma_aktif, aidat_gecmis_aktif, paket_bitim_aktif, dogum_gunu_aktif FROM whatsapp_mesaj_ayarlari LIMIT 1');
            results.mesaj_ayarlari_cron_kolonlari = true;
        } catch (e) {
            errors.push('whatsapp_mesaj_ayarlari cron kolonları eksik: ' + e.message);
        }

        // 6. whatsapp_mesaj_log'da referans kolonları var mı?
        try {
            await db.execute('SELECT referans_ay, referans_yil, referans_id FROM whatsapp_mesaj_log LIMIT 1');
            results.mesaj_log_referans_kolonlari = true;
        } catch (e) {
            errors.push('whatsapp_mesaj_log referans kolonları eksik: ' + e.message);
        }

        const allOk = Object.values(results).every(v => v === true || typeof v === 'number');

        res.json({
            success: allOk,
            message: allOk ? 'Tüm veritabanı yapısı hazır!' : 'Bazı eksiklikler var, SQL güncellemesi yapın.',
            results,
            errors,
            sqlFile: 'whatsapp_cron_sql.sql dosyasını çalıştırın'
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Veritabanı kontrol hatası: ' + error.message,
            results,
            errors
        });
    }
});

// Aidat hatırlatma cron testi
router.get('/cron/test/aidat-hatirlatma', authCheck, adminCheck, async (req, res) => {
    try {
        console.log('🧪 Aidat hatırlatma cron testi...');
        await cronService.aidatHatirlatmaCron();
        res.json({ success: true, message: 'Aidat hatırlatma cron tamamlandı' });
    } catch (error) {
        console.error('Aidat hatırlatma cron hatası:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// Gecikmiş aidat cron testi
router.get('/cron/test/aidat-gecmis', authCheck, adminCheck, async (req, res) => {
    try {
        console.log('🧪 Gecikmiş aidat cron testi...');
        await cronService.aidatGecikmisCron();
        res.json({ success: true, message: 'Gecikmiş aidat cron tamamlandı' });
    } catch (error) {
        console.error('Gecikmiş aidat cron hatası:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// Paket bitiş cron testi
router.get('/cron/test/paket-bitim', authCheck, adminCheck, async (req, res) => {
    try {
        console.log('🧪 Paket bitiş cron testi...');
        await cronService.paketBitimCron();
        res.json({ success: true, message: 'Paket bitiş cron tamamlandı' });
    } catch (error) {
        console.error('Paket bitiş cron hatası:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// Özel ders bitiş cron testi
router.get('/cron/test/ozel-ders-bitim', authCheck, adminCheck, async (req, res) => {
    try {
        console.log('🧪 Özel ders bitiş cron testi...');
        await cronService.ozelDersBitimCron();
        res.json({ success: true, message: 'Özel ders bitiş cron tamamlandı' });
    } catch (error) {
        console.error('Özel ders bitiş cron hatası:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// Taksit hatırlatma cron testi
router.get('/cron/test/taksit-hatirlatma', authCheck, adminCheck, async (req, res) => {
    try {
        console.log('🧪 Taksit hatırlatma cron testi...');
        await cronService.taksitHatirlatmaCron();
        res.json({ success: true, message: 'Taksit hatırlatma cron tamamlandı' });
    } catch (error) {
        console.error('Taksit hatırlatma cron hatası:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// Doğum günü cron testi
router.get('/cron/test/dogum-gunu', authCheck, adminCheck, async (req, res) => {
    try {
        console.log('🧪 Doğum günü cron testi...');
        await cronService.dogumGunuCron();
        res.json({ success: true, message: 'Doğum günü cron tamamlandı' });
    } catch (error) {
        console.error('Doğum günü cron hatası:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// Cron durumunu görüntüle
router.get('/cron/status', authCheck, adminCheck, async (req, res) => {
    try {
        // Son 24 saatteki cron loglarını getir
        const [logs] = await db.execute(`
            SELECT 
                mesaj_tipi,
                durum,
                COUNT(*) as adet,
                MAX(gonderim_tarihi) as son_gonderim
            FROM whatsapp_mesaj_log
            WHERE gonderim_tarihi >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            AND mesaj_tipi IN ('aidat_hatirlatma', 'aidat_gecmis', 'paket_bitim', 'ozel_ders_bitim', 'paket_taksit_hatirlatma', 'ozel_taksit_hatirlatma', 'dogum_gunu')
            GROUP BY mesaj_tipi, durum
            ORDER BY son_gonderim DESC
        `);

        res.json({ 
            success: true, 
            message: 'Son 24 saatteki cron aktiviteleri',
            logs: logs 
        });
    } catch (error) {
        console.error('Cron status hatası:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// =====================================================
// 📅 PLANLI MESAJ ENDPOİNTLERİ
// =====================================================

// Planlı mesajları listele
router.get('/planli-mesajlar', authCheck, async (req, res) => {
    const subeId = req.query.sube_id || req.session.subeId;
    
    try {
        const [mesajlar] = await db.execute(`
            SELECT pm.*, o.ad_soyad as ogrenci_adi
            FROM whatsapp_planli_mesajlar pm
            LEFT JOIN ogrenciler o ON pm.ogrenci_id = o.id
            WHERE pm.sube_id = ?
            AND pm.durum IN ('bekliyor', 'iptal')
            ORDER BY pm.gonderim_zamani ASC
        `, [subeId]);
        
        res.json({ success: true, mesajlar: mesajlar });
    } catch (error) {
        console.error('Planlı mesaj listesi hatası:', error);
        res.json({ success: false, message: error.message });
    }
});

// Planlı mesaj ekle
router.post('/planli-mesaj/ekle', authCheck, async (req, res) => {
    const { telefon, mesaj, gonderim_zamani, ogrenci_id } = req.body;
    const subeId = req.body.sube_id || req.session.subeId;
    
    if (!telefon || !mesaj || !gonderim_zamani) {
        return res.status(400).json({ success: false, message: 'Eksik parametreler' });
    }
    
    try {
        // Telefon formatla
        let phone = telefon.toString().replace(/\D/g, '');
        if (phone.length === 10) phone = '90' + phone;
        if (phone.length === 11 && phone[0] === '0') phone = '90' + phone.substring(1);
        
        await db.execute(`
            INSERT INTO whatsapp_planli_mesajlar 
            (sube_id, ogrenci_id, telefon, mesaj, gonderim_zamani, durum, olusturma_tarihi)
            VALUES (?, ?, ?, ?, ?, 'bekliyor', NOW())
        `, [subeId, ogrenci_id || null, phone, mesaj, gonderim_zamani]);
        
        res.json({ success: true, message: 'Planlı mesaj eklendi' });
    } catch (error) {
        console.error('Planlı mesaj ekleme hatası:', error);
        res.json({ success: false, message: error.message });
    }
});

// Planlı mesaj iptal et
router.post('/planli-mesaj/iptal/:id', authCheck, async (req, res) => {
    const { id } = req.params;
    const subeId = req.session.subeId;
    
    try {
        await db.execute(`
            UPDATE whatsapp_planli_mesajlar 
            SET durum = 'iptal'
            WHERE id = ? AND sube_id = ?
        `, [id, subeId]);
        
        res.json({ success: true, message: 'Planlı mesaj iptal edildi' });
    } catch (error) {
        console.error('Planlı mesaj iptal hatası:', error);
        res.json({ success: false, message: error.message });
    }
});

// Planlı mesaj sil
router.delete('/planli-mesaj/:id', authCheck, async (req, res) => {
    const { id } = req.params;
    const subeId = req.session.subeId;
    
    try {
        await db.execute(`
            DELETE FROM whatsapp_planli_mesajlar 
            WHERE id = ? AND sube_id = ?
        `, [id, subeId]);
        
        res.json({ success: true, message: 'Planlı mesaj silindi' });
    } catch (error) {
        console.error('Planlı mesaj silme hatası:', error);
        res.json({ success: false, message: error.message });
    }
});

// =====================================================
// 📊 MESAJ LOG ENDPOİNTLERİ
// =====================================================

// Mesaj loglarını listele
router.get('/mesaj-loglari', authCheck, async (req, res) => {
    const subeId = req.query.sube_id || req.session.subeId;
    const { mesaj_tipi, durum, baslangic, bitis, limit = 100 } = req.query;
    
    try {
        let sql = `
            SELECT ml.*, o.ad_soyad as ogrenci_adi
            FROM whatsapp_mesaj_log ml
            LEFT JOIN ogrenciler o ON ml.ogrenci_id = o.id
            WHERE ml.sube_id = ?
        `;
        const params = [subeId];
        
        if (mesaj_tipi) {
            sql += ` AND ml.mesaj_tipi = ?`;
            params.push(mesaj_tipi);
        }
        
        if (durum) {
            sql += ` AND ml.durum = ?`;
            params.push(durum);
        }
        
        if (baslangic) {
            sql += ` AND DATE(ml.gonderim_tarihi) >= ?`;
            params.push(baslangic);
        }
        
        if (bitis) {
            sql += ` AND DATE(ml.gonderim_tarihi) <= ?`;
            params.push(bitis);
        }
        
        sql += ` ORDER BY ml.gonderim_tarihi DESC LIMIT ?`;
        params.push(parseInt(limit));
        
        const [loglar] = await db.execute(sql, params);
        
        res.json({ success: true, loglar: loglar });
    } catch (error) {
        console.error('Mesaj log listesi hatası:', error);
        res.json({ success: false, message: error.message });
    }
});

// Mesaj istatistikleri
router.get('/mesaj-istatistikleri', authCheck, async (req, res) => {
    const subeId = req.query.sube_id || req.session.subeId;
    const { gun = 30 } = req.query;
    
    try {
        // Genel istatistikler
        const [genel] = await db.execute(`
            SELECT 
                COUNT(*) as toplam,
                SUM(CASE WHEN durum = 'sent' THEN 1 ELSE 0 END) as gonderilen,
                SUM(CASE WHEN durum = 'delivered' THEN 1 ELSE 0 END) as teslim_edilen,
                SUM(CASE WHEN durum = 'read' THEN 1 ELSE 0 END) as okunan,
                SUM(CASE WHEN durum = 'failed' THEN 1 ELSE 0 END) as basarisiz
            FROM whatsapp_mesaj_log
            WHERE sube_id = ?
            AND gonderim_tarihi >= DATE_SUB(NOW(), INTERVAL ? DAY)
        `, [subeId, parseInt(gun)]);
        
        // Mesaj tipi bazında
        const [tipBazli] = await db.execute(`
            SELECT 
                mesaj_tipi,
                COUNT(*) as adet,
                SUM(CASE WHEN durum IN ('sent', 'delivered', 'read') THEN 1 ELSE 0 END) as basarili
            FROM whatsapp_mesaj_log
            WHERE sube_id = ?
            AND gonderim_tarihi >= DATE_SUB(NOW(), INTERVAL ? DAY)
            GROUP BY mesaj_tipi
            ORDER BY adet DESC
        `, [subeId, parseInt(gun)]);
        
        // Günlük dağılım
        const [gunluk] = await db.execute(`
            SELECT 
                DATE(gonderim_tarihi) as tarih,
                COUNT(*) as adet
            FROM whatsapp_mesaj_log
            WHERE sube_id = ?
            AND gonderim_tarihi >= DATE_SUB(NOW(), INTERVAL ? DAY)
            GROUP BY DATE(gonderim_tarihi)
            ORDER BY tarih ASC
        `, [subeId, parseInt(gun)]);
        
        res.json({ 
            success: true, 
            istatistikler: {
                genel: genel[0],
                tipBazli: tipBazli,
                gunluk: gunluk
            }
        });
    } catch (error) {
        console.error('Mesaj istatistik hatası:', error);
        res.json({ success: false, message: error.message });
    }
});

module.exports = router;